import { Text, View, StyleSheet } from "react-native"
import { AntDesign } from '@expo/vector-icons';
import { FontAwesome5 } from '@expo/vector-icons';
import { MaterialIcons } from '@expo/vector-icons';

interface Props {
    likes: number;
    reposts: number;
    comments: number;
}

const Footer = ({ likes, reposts, comments }: Props) => {

    const formatName = (value: string) => {
        return value.toUpperCase();
    }

    return (
        <View style={styles.container}>
            <View style={styles.item}>
                <AntDesign name="hearto" size={18} color="black" />
                <Text style={styles.text}>{likes}</Text>
            </View>
            <View style={styles.item}>
                <FontAwesome5 name="comments" size={18} color="black" />
                <Text style={styles.text}>{comments}</Text>
            </View>
            <View style={styles.item}>
                <MaterialIcons name="360" size={18} color="black" />
                <Text style={styles.text}>{reposts}</Text>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        justifyContent: 'space-between', 
        alignItems: 'center', 
        paddingLeft: 10, 
        paddingRight: 10,
        width: 250,
        height: 40
    },
    item: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    icon: {
        width: 20,
        height: 20,
        marginRight: 5,
    },
    text: {
        fontSize: 20,
        paddingLeft: 2,
        marginRight: 10,
    },
});

export default Footer;