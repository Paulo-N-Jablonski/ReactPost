import { Text, Image, View, StyleSheet } from "react-native"

interface Props {
    image: string;
    content: string;
}

const Content = ({ image, content }: Props) => {

    const formatName = (value: string) => {
        return value.toUpperCase();
    }

    return (
        <View style={styles.container}>
            <Text style={styles.textContent}>{content}</Text>
            <Image style={styles.imageContent} width={250} height={200} source={{uri: 'https://source.unsplash.com/random'}}/>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        justifyContent: 'center',
        alignItems: 'center',
        width: 250,
        height: 240,
        borderWidth: 1
    },
    imageContent: {
        top: 10
    },
    textContent: {
        fontSize: 14
    }
});

export default Content;