import { Image, Text, View, StyleSheet } from "react-native"

interface Props {
    userName: string;
    image: string;
}

const Header = ({ userName, image }: Props) => {

    const formatName = (value: string) => {
        return value.toUpperCase();
    }

    return (
        <View style={styles.container}>
            <Image style={styles.image} width={40} height={40} borderRadius={50} source={{uri: image}}/>
            <Text style={styles.userName}>{userName}</Text>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        paddingTop: 10,
        paddingLeft: 10,
        paddingBottom: 10,
        alignItems: 'center', // Alterado de 'baseline' para 'center'
        width: 250,
        flexDirection: 'row'
    },
    image: {
        marginRight: 10
    },
    userName: {
        fontSize: 18
    }
});

export default Header;