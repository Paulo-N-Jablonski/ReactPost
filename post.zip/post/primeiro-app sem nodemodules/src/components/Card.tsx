import { View, StyleSheet } from "react-native"
import { FeedItem } from "../types/FeedItem";
import Header from "../components/Header";
import Content from "../components/Content";
import Footer from "../components/Footer";

const Card = ({ id, avatar, userName, content, image, likes, reposts, comments }: FeedItem) => {

    const formatName = (value: string) => {
        return value.toUpperCase();
    }

    return (
        <View style={styles.container}>
            <Header
                userName={userName}
                image={image}
            />
            <Content
                content={content}
                image={image}
            />
            <Footer
                likes={likes}
                reposts={reposts}
                comments={comments}
            />
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 1,
        marginVertical: 10,
    }
});

export default Card;