import { FeedItem } from "../types/FeedItem";
import { Card } from 'galio-framework';
import { AntDesign } from '@expo/vector-icons';
import { FontAwesome5 } from '@expo/vector-icons';
import { MaterialIcons } from '@expo/vector-icons';
import { StyleSheet, Text, Image, View } from "react-native";

const CardItem = ({ id, avatar, userName, content, image, likes, reposts, comments }: FeedItem) => {

    const formatName = (value: string) => {
        return value.toUpperCase();
    }

    return (
        <Card
            flex
            borderless
            style={styles.card}
            title={userName}
            avatar={avatar}
        >
            <View style={styles.contentCenter}>
                <Text>{content}</Text>
            </View>
            <Image style={styles.image} source={{ uri: `${image}`, }}/>
            <View style={styles.information}>
                <View style={styles.item}>
                    <AntDesign name="hearto" size={14} color="black" />
                    <Text>{likes}</Text>
                </View>
                <View style={styles.item}>
                    <FontAwesome5 name="comments" size={14} color="black" />
                    <Text>{comments}</Text>
                </View>
                <View style={styles.item}>
                    <MaterialIcons name="360" size={14} color="black" />
                    <Text>{reposts}</Text>
                </View>
            </View>
        </Card>
    )
}

const styles = StyleSheet.create({
    card: {
        borderWidth: 1,
        marginVertical: 10,
        width: 250,
        padding: 10
    },
    contentCenter: {
        alignItems: 'center',
        justifyContent: 'center'
    },
    item: {
        flexDirection: 'row',
        alignItems: 'center'
    },
    image: {
        width: 230,
        height: 200,
        borderRadius: 10
    },
    information: {
        flexDirection: 'row',
        justifyContent: 'space-between', 
        paddingLeft: 25,
        paddingRight: 25,
        paddingTop: 5
    }
});

export default CardItem;