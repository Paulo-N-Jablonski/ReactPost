import { View, Text, StyleSheet, FlatList } from "react-native";
import Card from "../components/Card";
import { FeedItem } from "../types/FeedItem";
import CardItem from "../components/Card";

const Home = () => {
  const posts: FeedItem[] = [
    {
      id: "1",
      avatar: "https://source.unsplash.com/random",
      userName: "Paulo",
      content: "Flor Amarela",
      image: "https://source.unsplash.com/random",
      likes: 10,
      reposts: 50,
      comments: 100,
    },
    {
      id: "2",
      avatar: "https://source.unsplash.com/random",
      userName: "José",
      content: "Flor Vermalha (For Daltonics)",
      image: "https://source.unsplash.com/random",
      likes: 1,
      reposts: 5,
      comments: 10,
    },
  ];

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Posts</Text>
      <FlatList
        data={posts}
        renderItem={({ item }) => (
          <CardItem
            id={item.id}
            avatar={item.avatar}
            userName={item.userName}
            content={item.content}
            image={item.image}
            likes={item.likes}
            reposts={item.reposts}
            comments={item.comments}
          />
        )}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "flex-start",
    alignItems: "center",
  },
  title: {
    fontSize: 50,
    marginVertical: 20,
    fontWeight: "bold",
  },
});

export default Home;